<?php $__env->startSection("title"); ?>
	<?php echo $__env->yieldContent("title"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
	<div class="container">

		<div class="row d-flex justify-content-between">
			<h2><?php echo $__env->yieldContent("header"); ?></h2>
			<a class="btn btn-success btn-lg" href="<?php echo $__env->yieldContent("addButtonRoute"); ?>"><?php echo $__env->yieldContent("addButtonText"); ?></a>
		</div>

		<table class="table table-bordered mt-3">
			<thead>
				<?php echo $__env->yieldContent("tableHead"); ?>
			</thead>
			<tbody>
			<?php echo $__env->yieldContent("tableBody"); ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>












<?php echo $__env->make("welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/parts/index.blade.php ENDPATH**/ ?>
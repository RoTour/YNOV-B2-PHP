<?php $__env->startSection("title"); ?>
	<?php echo $__env->yieldContent("title"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
	<div class="container">
		<h2 class="font-weight-bold"><?php echo $__env->yieldContent("header"); ?></h2>
		<form method="POST" action="<?php echo $__env->yieldContent("action"); ?>">
			<?php echo csrf_field(); ?>
			<?php echo $__env->yieldContent("method"); ?>
			<div class="row">
				<div class="mb-3 col-6">
					<label for="name" class="form-label">Name</label>
					<input type="text" class="form-control" id="name" name="name" value="<?php echo $__env->yieldContent("name"); ?>" required>
				</div>
				<div class="mb-3 col-6">
					<label for="speciality" class="form-label">Speciality</label>
					<input type="text" class="form-control" id="speciality" name="speciality" value="<?php echo $__env->yieldContent("speciality"); ?>"
								 required>
				</div>
			</div>

			<p class="font-weight-bold mt-3 font" style="font-size: 2em">Modules : </p>
			<div class="row col-12">
				<?php $__currentLoopData = $modules_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-check col-3">
						<input type="checkbox" class="form-check-input" name="modules[]" value="<?php echo e($module->id); ?>"
									 id="module-<?php echo e($module->id); ?>"
									 <?php if(isset($editing_promo) && $editing_promo->modules->contains($module->id)): ?> checked <?php endif; ?>>
						<label class="form-check-label" for="module-<?php echo e($module->id); ?>"><?php echo e($module->name); ?></label>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<p class="font-weight-bold mt-3 font" style="font-size: 2em">Students : </p>
			<div class="row col-12">
				<?php $__currentLoopData = $students_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-check col-3">
						<input type="checkbox" class="form-check-input" name="students[]" value="<?php echo e($student->id); ?>"
									 id="student-<?php echo e($student->id); ?>"
									 <?php if(isset($editing_promo) && $editing_promo->students->contains($student->id)): ?> checked <?php endif; ?>>
						<label class="form-check-label" for="student-<?php echo e($student->id); ?>"><?php echo e($student->full_name()); ?></label>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<button type="submit" class="btn btn-primary mt-3 mb-5">Submit</button>
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/promo/form.blade.php ENDPATH**/ ?>
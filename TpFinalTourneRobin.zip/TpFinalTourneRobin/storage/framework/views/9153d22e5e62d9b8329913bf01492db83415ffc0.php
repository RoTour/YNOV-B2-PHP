<?php $__env->startSection("title"); ?>
	<?php echo e($promo->infos()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
	<div class="container d-flex justify-content-center">
		<div class="card" style="width: 36rem;">
			<div class="card-body">
				<h5 class="card-title"><?php echo e($promo->infos()); ?></h5>

				<h6 class="mt-3">Modules: </h6>
				<div class="row">
					<?php $__currentLoopData = $promo->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="col-6" href="<?php echo e(route("student.show", $promo_module)); ?>">
							<?php echo e($promo_module->name); ?></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>

				<h6 class="mt-3">Students: </h6>
				<div class="row">
					<?php $__currentLoopData = $promo->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="col-6" href="<?php echo e(route("student.show", $promo_student)); ?>">
									<?php echo e($promo_student->full_name()); ?></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="d-flex mt-4">
					<a class="btn btn-outline-primary mr-2" href="<?php echo e(route("promo.edit", $promo)); ?>">Edit</a>
					<form action="<?php echo e(route("promo.destroy", $promo)); ?>" method="post">
						<input class="btn btn-outline-danger" type="submit" value="Delete"/>
						<?php echo method_field('delete'); ?>
						<?php echo csrf_field(); ?>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/promo/show.blade.php ENDPATH**/ ?>
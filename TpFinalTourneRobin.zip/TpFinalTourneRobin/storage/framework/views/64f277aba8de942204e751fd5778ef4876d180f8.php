<?php $__env->startSection("title"); ?> Modules <?php $__env->stopSection(); ?>
<?php $__env->startSection("header"); ?>
	<?php if($search): ?>
		Modules - Result for: <?php echo e($search); ?>

	<?php else: ?>
		Modules at Fiction Ynov Campus:
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("addButtonRoute"); ?> <?php echo e(route("module.create")); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("addButtonText"); ?> Add Module <?php $__env->stopSection(); ?>
<?php $__env->startSection("tableHead"); ?>
	<tr>
		<th>Name</th>
		<th>Description</th>
		<th>Actions</th>
	</tr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("tableBody"); ?>
	<?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($module->name); ?></td>
			<td><?php echo e($module->description); ?></td>
			<td class="d-flex justify-content-around border-bottom-0">
				<a class="btn btn-outline-success mr-2" href="<?php echo e(route("module.show", $module)); ?>">Show</a>
				<a class="btn btn-outline-primary mr-2" href="<?php echo e(route("module.edit", $module)); ?>">Edit</a>
				<form action="<?php echo e(route("module.destroy", $module)); ?>" method="post">
					<input class="btn btn-outline-danger" type="submit" value="Delete"/>
					<?php echo method_field('delete'); ?>
					<?php echo csrf_field(); ?>
				</form>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("parts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/module/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title"); ?>Edit Promo <?php $__env->stopSection(); ?>
<?php $__env->startSection("header"); ?> Edit Promotion <?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?><?php echo e(route("promo.update", $editing_promo)); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("method"); ?> <?php echo method_field("PUT"); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("name"); ?> <?php echo e($editing_promo->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("speciality"); ?> <?php echo e($editing_promo->speciality); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make("promo.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/promo/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title"); ?>Edit Promo <?php $__env->stopSection(); ?>
<?php $__env->startSection("header"); ?> Add Promotion <?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?><?php echo e(route("promo.store")); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make("promo.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/promo/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title"); ?>
	<?php echo $__env->yieldContent("title"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
	<div class="container">
		<h2 class="font-weight-bold"><?php echo $__env->yieldContent("header"); ?></h2>
		<form method="POST" action="<?php echo $__env->yieldContent("action"); ?>">
			<?php echo csrf_field(); ?>
			<?php echo $__env->yieldContent("method"); ?>
			<div class="row">
				<div class="mb-3 col-6">
					<label for="firstname" class="form-label">Firstname</label>
					<input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $__env->yieldContent("firstname"); ?>" required>
				</div>
				<div class="mb-3 col-6">
					<label for="lastname" class="form-label">Lastname</label>
					<input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $__env->yieldContent("lastname"); ?>" required>
				</div>
			</div>
			<div class="row">
				<div class="mb-3 col-6">
					<label for="email" class="form-label">Email</label>
					<input type="email" class="form-control" id="email" name="email" value="<?php echo $__env->yieldContent("email"); ?>" required>
				</div>
			</div>

			<p class="font-weight-bold mt-3 font" style="font-size: 2em">Promotions : </p>
			<div class="row col-12">
				<?php $__currentLoopData = $promos_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-check col-3">
						<input class="form-check-input" type="radio" name="promo_id" value="<?php echo e($promo->id); ?>"
									 id="promo-<?php echo e($promo->id); ?>"
									 <?php if(isset($editing_student) && isset($editing_student->promo) && $editing_student->promo->id == $promo->id): ?> checked <?php endif; ?>>
						<label class="form-check-label"
									 for="promo-<?php echo e($promo->id); ?>"><?php echo e($promo->infos()); ?></label>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<p class="font-weight-bold mt-3 font" style="font-size: 2em">Modules : </p>
			<div class="row col-12">
				<?php $__currentLoopData = $modules_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-check col-3">
						<input type="checkbox" class="form-check-input" name="modules[]" value="<?php echo e($module->id); ?>"
									 id="module-<?php echo e($module->id); ?>"
									 <?php if(isset($editing_student) && $editing_student->modules->contains($module->id)): ?> checked <?php endif; ?>>
						<label class="form-check-label" for="module-<?php echo e($module->id); ?>"><?php echo e($module->name); ?></label>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<button type="submit" class="btn btn-primary mt-3 mb-5">Submit</button>
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/student/form.blade.php ENDPATH**/ ?>
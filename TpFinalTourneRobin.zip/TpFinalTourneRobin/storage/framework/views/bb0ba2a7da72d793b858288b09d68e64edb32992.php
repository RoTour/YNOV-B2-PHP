<nav class="navbar navbar-expand-lg navbar-light bg-dark mb-3">
	<a class="navbar-brand text-white" href="<?php echo e(route("student.index")); ?>">UltraPlanning</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active">
				<a class="nav-link text-white" href="<?php echo e(route("student.index")); ?>">Student List</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link text-white" href="<?php echo e(route("promo.index")); ?>">Promos List</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link text-white" href="<?php echo e(route("module.index")); ?>">Modules List</a>
			</li>
		</ul>
		<form class="form-inline my-2 my-lg-0" method="get">
			<input class="form-control mr-sm-2" name="search" type="search" placeholder="Search" aria-label="Search">
			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
		</form>
	</div>
</nav>
<?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/navbar.blade.php ENDPATH**/ ?>
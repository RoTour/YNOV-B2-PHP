<?php $__env->startSection("title"); ?> Promotions <?php $__env->stopSection(); ?>
<?php $__env->startSection("header"); ?>
	<?php if($search): ?>
		Promotions - Result for: <?php echo e($search); ?>

	<?php else: ?>
		Promotions at Fiction Ynov Campus:
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("addButtonRoute"); ?> <?php echo e(route("promo.create")); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("addButtonText"); ?> Add Promo <?php $__env->stopSection(); ?>
<?php $__env->startSection("tableHead"); ?>
	<tr>
		<th>Name</th>
		<th>Speciality</th>
		<th>Actions</th>
	</tr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("tableBody"); ?>
	<?php $__currentLoopData = $promos_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($promo->name); ?></td>
			<td><?php echo e($promo->speciality); ?></td>
			<td class="d-flex justify-content-around border-bottom-0">
				<a class="btn btn-outline-success mr-2" href="<?php echo e(route("promo.show", $promo)); ?>">Show</a>
				<a class="btn btn-outline-primary mr-2" href="<?php echo e(route("promo.edit", $promo)); ?>">Edit</a>
				<form action="<?php echo e(route("promo.destroy", $promo)); ?>" method="post">
					<input class="btn btn-outline-danger" type="submit" value="Delete"/>
					<?php echo method_field('delete'); ?>
					<?php echo csrf_field(); ?>
				</form>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("parts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/promo/index.blade.php ENDPATH**/ ?>
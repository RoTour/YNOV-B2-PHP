<?php $__env->startSection("title"); ?>Create Student <?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?><?php echo e(route("student.store")); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make("student.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/student/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title"); ?>
	<?php echo e($student->firstname." ".$student->lastname); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
	<div class="container d-flex justify-content-center">
		<div class="card" style="width: 36rem;">
			<div class="card-body">

				<h5 class="card-title"><?php echo e($student->firstname." ".$student->lastname); ?></h5>

				<h6 class="card-subtitle mb-2 text-muted"><?php echo e($student->email); ?></h6>

				<h6 class="mt-3">Promotion: </h6>
				<a href="<?php echo e(route("promo.show", $student->promo)); ?>"><?php echo e($student->promo->infos()); ?></a>

				<h6 class="mt-3">Modules: </h6>
				<div class="row">
					<?php $__currentLoopData = $student->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="col-6" href="<?php echo e(route("module.show", $student_module)); ?>">
							<?php echo e($student_module->name); ?></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>

				<div class="d-flex mt-4">
					<a class="btn btn-outline-primary mr-2" href="<?php echo e(route("student.edit", $student)); ?>">Edit</a>
					<form action="<?php echo e(route("student.destroy", $student)); ?>" method="post">
						<input class="btn btn-outline-danger" type="submit" value="Delete"/>
						<?php echo method_field('delete'); ?>
						<?php echo csrf_field(); ?>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/student/show.blade.php ENDPATH**/ ?>
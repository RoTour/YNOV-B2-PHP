<?php $__env->startSection("title"); ?>Add Module <?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?><?php echo e(route("module.store")); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make("module.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/module/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title"); ?>Edit Module <?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?><?php echo e(route("module.update", $editing_module)); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("method"); ?> <?php echo method_field("PUT"); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("name"); ?> <?php echo e($editing_module->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("description"); ?> <?php echo e($editing_module->description); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make("module.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TpFinalTourneRobin\resources\views/module/edit.blade.php ENDPATH**/ ?>
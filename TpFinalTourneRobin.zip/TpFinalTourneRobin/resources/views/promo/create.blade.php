@extends("promo.form")
@section("title")Edit Promo @endsection
@section("header") Add Promotion @endsection
@section("action"){{ route("promo.store") }} @endsection

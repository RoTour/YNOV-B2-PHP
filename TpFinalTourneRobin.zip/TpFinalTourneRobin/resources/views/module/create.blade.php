@extends("module.form")
@section("title")Add Module @endsection
@section("header") Add Module @endsection
@section("action"){{ route("module.store") }} @endsection

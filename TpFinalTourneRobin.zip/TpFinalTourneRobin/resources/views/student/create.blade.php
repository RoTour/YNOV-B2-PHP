@extends("student.form")
@section("title")Create Student @endsection
@section("header") Add Student @endsection
@section("action"){{ route("student.store") }} @endsection

